module.exports ={
    MONGOURI: "mongodb+srv://Amit:nLIPHXOwUedI6z1a@cluster0.mxhf5.mongodb.net/<dbname>?retryWrites=true&w=majority"
 }
 //mongodb password
//nLIPHXOwUedI6z1a